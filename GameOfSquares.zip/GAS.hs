{-# OPTIONS_GHC -Wall #-}
{-# LANGUAGE MultiParamTypeClasses,
             TypeSynonymInstances, FlexibleInstances #-}

module GAS where

import ProblemState
import Data.Maybe

import qualified Data.Map.Strict as M

{-
    Pozițiile tablei de joc, în formă (linie, coloană), unde ambele coordonate
    pot fi negative.
-}
type Position = (Int, Int)

{-
    Culorile pătratelor și cercurilor.
-}
data Color = Red | Blue | Gray
    deriving (Eq, Ord)

instance Show Color where
    show Red = "R"
    show Blue = "B"
    show Gray  = "G"

{-
    Orientările pătratelor și săgeților.
-}
data Heading = North | South | East | West
    deriving (Eq, Ord)

instance Show Heading where
    show North = "^"
    show South = "v"
    show East  = ">"
    show West  = "<"

{-
    *** TODO ***

    Un obiect de pe tabla de joc: pătrat/ cerc/ săgeată.
-}
--data Object = Patrat { culoare1 :: Color
  --           , directie1 :: Heading
    --         } | Cerc { culoare2 :: Color
      --       } | Sageata { directie2 :: Heading
        --        }
        --deriving (Eq, Ord)

{-
 Pentru implementarea obiectelor de pe tabla,
   mi-a fost mai la indemana sa fac cate un data
   pentru fiecare forma
-}

data Patrat = Patrat { culoare1 :: Color
             , directie1 :: Heading
             } deriving (Eq, Ord)

data Cerc = Cerc { culoare2 :: Color
             } deriving (Eq, Ord)

data Sageata = Sageata { directie2 :: Heading
                } deriving (Eq, Ord)

{-
    *** TODO ***

    Reprezetarea textuală a unui obiect.
-}

{-
 Am facut aici fiecare forma sa fie de tip Show, pentru
    a afisa asa cum se doreste
-}

instance Show Patrat where
    show (Patrat c d) = (show c) ++ (show d) 

instance Show Cerc where
    show (Cerc c) = if c == Red then "r" 
                    else if c == Blue then "b"
                         else "g"

instance Show Sageata where
    show (Sageata d) = show d


{-
    *** TODO ***

    Un nivel al jocului.

    Recomandăm Data.Map.Strict.
-}

{-
 O cheie este formata dintr-un triplet de
    Maybe Patrat, Maybe Cerc, Maybe Sageata
-}

data Level = Level (M.Map Position (Maybe Patrat, Maybe Cerc, Maybe Sageata))
    deriving (Eq, Ord)

{-
    *** TODO ***

    Reprezetarea textuală a unui nivel.
-}

{-
 Pentru aceasta functie am calculat coloana minima si linia maxima
    si folosind 2 map-uri, am iterat prin elemente. In caz de cheie vida
    am afisat spatii, iar altfel am afisat ce era acolo
-}

cols :: Level -> [Int]
cols (Level mapa) = map (\((_,y), (_, _, _)) -> y) (M.toList mapa)

linea :: Level -> [Int]
linea (Level mapa) = map (\((x,_), (_, _, _)) -> x) (M.toList mapa)

maxic :: [Int] -> Int
maxic [x] = x
maxic (x:xs) = max x (maxic xs)

minic :: [Int] -> Int
minic [x] = x
minic (x:xs) = min x (minic xs)

transform :: (Maybe Patrat, Maybe Cerc, Maybe Sageata) -> String
transform (patrat, cerc, sageata) = if (isJust (patrat)) && (not (isJust (cerc))) && (not (isJust (sageata))) 
                                    then (show (fromJust patrat)) ++ " " else 
                                    if (not (isJust (patrat))) && (isJust (cerc)) && (not (isJust (sageata))) then
                                        "  " ++ (show (fromJust cerc)) else
                                     if (not (isJust (patrat))) && (not (isJust (cerc))) && (isJust (sageata)) then
                                        "  " ++ (show (fromJust sageata)) else 
                                    if (isJust (patrat)) && (isJust (cerc)) && (not (isJust (sageata))) then
                                        (show (fromJust patrat)) ++ (show (fromJust cerc)) else 
                                            ((show (fromJust patrat)) ++ (show (fromJust sageata)))

instance Show Level where
    show (Level mapa) = concatMap (\x -> concatMap (\y -> 
                                    if (M.member (x, y) mapa) then 
                                        (if (x <= maxLin && y < maxCol) then 
                                            ((transform (fromJust (M.lookup (x, y) mapa))) ++ "|") else 
                                                if (x < maxLin && y == maxCol) then
                                                    ((transform (fromJust (M.lookup (x, y) mapa))) ++ "\n") else 
                                                        (transform (fromJust (M.lookup (x, y) mapa))))
                                    else 
                                        (if (x <= maxLin && y < maxCol) then 
                                            ("   |") else 
                                                if (x < maxLin && y == maxCol) then
                                                    ("   \n") else 
                                                        "   " )) [y | y <- [minCol .. maxCol]])
                                    [x | x <- [minLin .. maxLin]] where

                                    coloane = cols (Level mapa)
                                    linii   = linea (Level mapa)
                                    maxCol  = maxic coloane
                                    maxLin  = maxic linii
                                    minLin = minic linii
                                    minCol = minic coloane
{-
    *** TODO ***

    Nivelul vid, fără obiecte.
-}
emptyLevel :: Level
emptyLevel = Level M.empty

{-
    *** TODO ***

    Adaugă un pătrat cu caracteristicile date la poziția precizată din nivel.
-}

{-
    Pentru urmatoarele functii suntem nevoiti sa
    facem pattern matching, intrucat trebuie
    sa pastram ceea ce era acolo atunci cand se
    adauga o noua forma la o cheie
-}
addSquare :: Color -> Heading -> Position -> Level -> Level
addSquare c d (x, y) (Level mapa) = Level (M.insert (x, y) ((Just (Patrat c d)), cerc, sageata) mapa) where
                                    (_, cerc, sageata) = if (isJust (M.lookup (x, y) mapa)) then (fromJust (M.lookup (x, y) mapa))
                                     else (Nothing, Nothing, Nothing)


{-
    *** TODO ***

    Adaugă un cerc cu caracteristicile date la poziția precizată din nivel.
-}
addCircle :: Color -> Position -> Level -> Level
addCircle c (x, y) (Level mapa) = Level (M.insert (x, y) (patrat, (Just (Cerc c)), sageata) mapa) where
                                    (patrat, _, sageata) = if (isJust (M.lookup (x, y) mapa)) then (fromJust (M.lookup (x, y) mapa))
                                     else (Nothing, Nothing, Nothing)

{-
    *** TODO ***

    Adaugă o săgeată cu caracteristicile date la poziția precizată din nivel.
-}
addArrow :: Heading -> Position -> Level -> Level
addArrow d (x, y) (Level mapa) = Level (M.insert (x, y) (patrat, cerc, (Just (Sageata d))) mapa) where
                                    (patrat, cerc, _) = if (isJust (M.lookup (x, y) mapa)) then (fromJust (M.lookup (x, y) mapa))
                                     else (Nothing, Nothing, Nothing)

{-
    *** TODO ***

    Mută pătratul de la poziția precizată din nivel. Dacă la poziția respectivă
    nu se găsește un pătrat, întoarce direct parametrul.
-}

{-
    Am folosit o recursivitate pentru mutarea mai multor patrate
-}

getPatrat :: (Maybe Patrat, Maybe Cerc, Maybe Sageata) -> Patrat
getPatrat (patrat, _, _) = fromJust patrat

getSageata :: (Maybe Patrat, Maybe Cerc, Maybe Sageata) -> Sageata
getSageata (_, _, sageata) = fromJust sageata

verifPatrat :: (Maybe Patrat, Maybe Cerc, Maybe Sageata) -> Bool
verifPatrat (patrat, _, _) = (isJust patrat)

helper :: Patrat -> (Color, Heading)
helper (Patrat c d) = (c, d) 

getDir :: Position -> Patrat -> Position
getDir (x, y) (Patrat _ d) = if d == North then (x - 1, y)
                                else if d == South then (x + 1, y)
                                else if d == East then (x, y + 1)
                                else (x, y - 1)

sterge :: (Maybe Patrat, Maybe Cerc, Maybe Sageata) -> (Maybe Patrat, Maybe Cerc, Maybe Sageata)
sterge (patrat, cerc, sageata) = if ((isJust cerc) || (isJust sageata)) && (isJust patrat) then (Nothing, cerc, sageata)
                                    else (patrat, cerc, sageata)

isSageata :: (Maybe Patrat, Maybe Cerc, Maybe Sageata) -> Bool
isSageata (patrat, cerc, sageata) = (isNothing patrat) && (isNothing cerc) && (isJust sageata) 

isPatrat :: (Maybe Patrat, Maybe Cerc, Maybe Sageata) -> Bool
isPatrat (patrat, cerc, sageata) = (isJust patrat) && (isNothing cerc) && (isNothing sageata)

getDire :: Sageata -> Heading
getDire (Sageata d) = d

getDirForMovePatrat :: Heading -> Position -> Position
getDirForMovePatrat d (x, y) = if d == North then (x - 1, y)
                                else if d == South then (x + 1, y)
                                else if d == East then (x, y + 1)
                                else (x, y - 1)

helperMove :: Heading -> Position -> Level -> Level
helperMove directie (x, y) (Level mapa) = if (M.member (x, y) mapa) && (verifPatrat (fromJust (M.lookup (x, y) mapa))) then
                                if (M.member (getDirForMovePatrat directie (x, y)) mapa) && (isPatrat (fromJust (M.lookup (getDirForMovePatrat directie (x, y)) mapa))) then
                                        helperMove directie (getDirForMovePatrat directie (x, y)) (Level mapa)
                                else addSquare (fst (helper (getPatrat (fromJust (M.lookup (x, y) mapa)) )) )
                                        (snd (helper (getPatrat (fromJust (M.lookup (x, y) mapa)) )))
                                        (getDirForMovePatrat directie (x, y))
                                        deletedLevel
                                    else (Level mapa) where
                                    deletedLevel = if (isPatrat (fromJust (M.lookup (x, y) mapa))) then (Level (M.delete (x, y) mapa))
                                     else (Level (M.insert (x, y) (sterge (fromJust (M.lookup (x, y) mapa))) mapa)) 

move :: Position  -- Poziția
     -> Level     -- Nivelul inițial
     -> Level     -- Nivelul final
move (x, y) (Level mapa) = if (M.member (x, y) mapa) && (verifPatrat (fromJust (M.lookup (x, y) mapa))) then
                               if (M.member (getDir (x, y) (getPatrat (fromJust (M.lookup (x, y) mapa)) )) mapa) && (isSageata (fromJust (M.lookup (getDir (x, y) (getPatrat (fromJust (M.lookup (x, y) mapa)) )) mapa))) then                            
                                    addSquare (fst (helper (getPatrat (fromJust (M.lookup (x, y) mapa)) )) )
                                        (getDire (getSageata (fromJust (M.lookup (getDir (x, y) (getPatrat (fromJust (M.lookup (x, y) mapa)) )) mapa))) )
                                        (getDir (x, y) (getPatrat (fromJust (M.lookup (x, y) mapa)) ))
                                        deletedLevel
                                else if (M.member (getDir (x, y) (getPatrat (fromJust (M.lookup (x, y) mapa)) )) mapa) && (isPatrat (fromJust (M.lookup (getDir (x, y) (getPatrat (fromJust (M.lookup (x, y) mapa)) )) mapa))) then
                                    (move (x, y) (helperMove (snd (helper (getPatrat (fromJust (M.lookup (x, y) mapa)) ))) (getDir (x, y) (getPatrat (fromJust (M.lookup (x, y) mapa)) )) (Level mapa)))
                                else addSquare (fst (helper (getPatrat (fromJust (M.lookup (x, y) mapa)) )) )
                                        (snd (helper (getPatrat (fromJust (M.lookup (x, y) mapa)) )))
                                        (getDir (x, y) (getPatrat (fromJust (M.lookup (x, y) mapa)) ))
                                        deletedLevel
                                    else (Level mapa) where
                                    deletedLevel = if (isPatrat (fromJust (M.lookup (x, y) mapa))) then (Level (M.delete (x, y) mapa))
                                     else (Level (M.insert (x, y) (sterge (fromJust (M.lookup (x, y) mapa))) mapa)) 
{-
    *** TODO ***

    Instanțiați clasa `ProblemState` pentru jocul nostru.
-}

getKeysPatrat :: Level -> [Position]
getKeysPatrat (Level mapa) = (filter (\cheie -> (isPatrat (fromJust (M.lookup cheie mapa)))) (M.keys mapa))

colPatr :: Maybe Patrat -> Color
colPatr (Just (Patrat c d)) = c

colCerc :: Maybe Cerc -> Color
colCerc (Just (Cerc c)) = c

isGoalPCCol :: (Maybe Patrat, Maybe Cerc, Maybe Sageata) -> Bool
isGoalPCCol (patrat, cerc, sageata) = (colPatr patrat == colCerc cerc)

isGoalPC :: (Maybe Patrat, Maybe Cerc, Maybe Sageata) -> Bool
isGoalPC (patrat, cerc, sageata) = (isJust patrat) && (isJust cerc) && (isNothing sageata) && (isGoalPCCol (patrat, cerc, sageata))

isGoalHelp :: Level -> [Position]
isGoalHelp (Level mapa) =  (filter (\cheie -> if (M.member cheie mapa) then (not (isGoalPC (fromJust (M.lookup cheie mapa)))) else False) (M.keys mapa))

isGoalHelp2 :: [Position] -> Level -> [Position]
isGoalHelp2 listaDupaScosPatrate (Level mapa) = (filter (\cheie -> if (M.member cheie mapa) then (not (isSageata (fromJust (M.lookup cheie mapa)))) else False) listaDupaScosPatrate)

instance ProblemState Level Position where

    successors (Level mapa) = if (Level mapa) == emptyLevel then [] else (map (\cheie -> (cheie, (move cheie (Level mapa))) ) (getKeysPatrat (Level mapa)))

    isGoal (Level mapa) = null (isGoalHelp2 (isGoalHelp (Level mapa)) (Level mapa))

    -- Doar petru BONUS
    -- heuristic
